export interface DetectedTopic {
  code: string; // e.g., "Topic 01"
  name: string;
  confidence: number; // percentage, e.g., 98.4
  description: string;
  tags: string[];
}

export interface KeywordFrequency {
  keyword: string;
  frequency: number;
}

export interface ExtractionMetric {
  marker: string;
  confidence: number;
  relevance: string;
  status: "Validated" | "Potential Noise" | "Filtered";
}

export interface DocumentMetadata {
  principalInvestigator: string;
  publicationYear: number;
  academicJournal: string;
  doi: string;
}

export interface ResearchPaper {
  id: string;
  title: string;
  analyzedAt: string;
  status: "PDF Analysis Complete" | "Analyzing..." | "Failed";
  metadata: DocumentMetadata;
  topics: DetectedTopic[];
  keywords: KeywordFrequency[];
  metrics: ExtractionMetric[];
  topologyImage: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  email: string;
  photoUrl: string;
  bio: string;
}
