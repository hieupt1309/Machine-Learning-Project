import { ResearchPaper, TeamMember } from "./types";

// Professional Black & White styling matching Screen 3 portraits
export const initialTeamMembers: TeamMember[] = [
  {
    id: "202416672",
    name: "Lê Trọng Đạt",
    role: "Member",
    email: "dat.lt2416672@sis.hust.edu.vn",
    photoUrl: "https://scontent.fhan17-1.fna.fbcdn.net/v/t39.30808-1/646207878_1449622540217832_3520092094129293428_n.jpg?stp=dst-jpg_tt6&cstp=mx1730x1729&ctp=s200x200&_nc_cat=102&ccb=1-7&_nc_sid=e99d92&_nc_eui2=AeG_E7NUmsrsRgjcuwlGuXkhveSnW7yJX0e95KdbvIlfR7RKDT5MGisYfPjVkVLLXO8Q9s8rVOXH1FH1rhvfvzGi&_nc_ohc=bXVGOx0ZT7QQ7kNvwFebDN-&_nc_oc=AdrYTJcFHXFAhIIZcRPIWN1pybOgCP4KYW_amXM4foZOB3j4zWpSyfm7iZefpBWS_xk&_nc_zt=24&_nc_ht=scontent.fhan17-1.fna&_nc_gid=SzmgN71eIZLInIxpnIaSTg&_nc_ss=7b2a8&oh=00_Af95BLYxigzShePR8mPOLVTB8JrV9Cat-pQ4CZIef9cpvQ&oe=6A3DCB6D", // Full color portrait
    bio: "Student at Hanoi University of Science and Technology."
  },
  {
    id: "202416669",
    name: "Doãn Hải Đăng",
    role: "Member",
    email: "dang.dh2416669@sis.hust.edu.vn",
    photoUrl: "https://scontent.fhan17-1.fna.fbcdn.net/v/t39.30808-1/463775295_1613703572848466_7018755623544092757_n.jpg?stp=cp6_dst-jpg_tt6&cstp=mx824x825&ctp=s200x200&_nc_cat=111&ccb=1-7&_nc_sid=1d2534&_nc_eui2=AeEOR5ctBZxj-cRcGFvtuEFYln18y8zwi-GWfXzLzPCL4TdvxlzwsRfNugFnUlGrguHa5Lz8w-zbndalpgMZ8gwo&_nc_ohc=Gl9mpXatUHoQ7kNvwHpZvPc&_nc_oc=AdoUz9yK1xQD_2KrnP6xWr8e_ltT1ojKoI44-g060iCrMK9XKdPQMOnqADNTCG7cX1s&_nc_zt=24&_nc_ht=scontent.fhan17-1.fna&_nc_gid=i7Q-T0CP46iyB1kemn5FVQ&_nc_ss=7b2a8&oh=00_Af8nOgdUjbni_-wou8Lecn4Jf4vFTafwfCLnccp2iW9cPg&oe=6A3DCE39", // Full color portrait
    bio: "Student at Hanoi University of Science and Technology."
  },
  {
    id: "202416670",
    name: "Lê Hải Đăng",
    role: "Member",
    email: "dang.lh2416670@sis.hust.edu.vn",
    photoUrl: "https://scontent.fhan17-1.fna.fbcdn.net/v/t39.30808-1/545416369_4133358083614381_3062633566098785583_n.jpg?stp=dst-jpg_tt6&cstp=mx1016x1022&ctp=s200x200&_nc_cat=103&ccb=1-7&_nc_sid=e99d92&_nc_eui2=AeFnDaAw3TajYl24pADiLLKSaLKFdULolBBosoV1QuiUED2BkktXKn0gxqCS0Wi3P43s9_FmZB59J2HNc6VQc-tW&_nc_ohc=SPiwg1qL8o0Q7kNvwGEl9mV&_nc_oc=Adq71Vdnt3-g4Endv7UpjlBoVMfSVfuttfDTKuEZslGqbptPGKu9pacnZoX1NHDetgQ&_nc_zt=24&_nc_ht=scontent.fhan17-1.fna&_nc_gid=2Bv2YZwh6-4A0F8UoOBJ7w&_nc_ss=7b2a8&oh=00_Af-eQM2Caeg-_-vxZgvfiN5jRloAHc3h0eDR5KITOaBl6g&oe=6A3DF9AD", // Full color portrait
    bio: "Student at Hanoi University of Science and Technology."
  },
  {
    id: "202416691",
    name: "Phạm Trung Hiếu",
    role: "Member",
    email: "hieu.pt2416691@sis.hust.edu.vn",
    photoUrl: "https://scontent.fhan17-1.fna.fbcdn.net/v/t39.30808-1/463742163_1089118705886235_7882293683262067201_n.jpg?stp=dst-jpg_tt6&cstp=mx736x724&ctp=s200x200&_nc_cat=104&ccb=1-7&_nc_sid=e99d92&_nc_eui2=AeGOf0r_HuxeigMZ3hPoG0ngPa5DrJPuCqM9rkOsk-4Ko8kLV1suL2iLS1L0-jVLLUn8t7w71SD8euIGc79qkRHJ&_nc_ohc=eNPDnPQ3XZEQ7kNvwEhGA4k&_nc_oc=AdqMG2wdZLqDoLdkheL5TY19d0mveAEeWJed71Sjs8kAAHaK0uBvzvCSQ-3AEgRatKo&_nc_zt=24&_nc_ht=scontent.fhan17-1.fna&_nc_gid=DU5yejhuEKmHfWjr48WBgA&_nc_ss=7b2a8&oh=00_Af-NTS_mtgs2D0XuPOFjY81oVBt3Lxrd6IqZyXlaiXy3nQ&oe=6A3DDB4F",
    bio: "Student at Hanoi University of Science and Technology."
  },
  {
    id: "202416697",
    name: "Nguyễn Minh Hoàng",
    role: "Member",
    email: "Hoang.nm2416697@sis.hust.edu.vn",
    photoUrl: "https://scontent.fhan17-1.fna.fbcdn.net/v/t39.30808-1/687041566_2013728576160748_7777865575748618122_n.jpg?stp=dst-jpg_tt6&cstp=mx960x960&ctp=s200x200&_nc_cat=107&ccb=1-7&_nc_sid=e99d92&_nc_eui2=AeETQ-X76Z0Xb672sMqhRsMx8Pc8n19KUwbw9zyfX0pTBhgGN4v9DMd55iMaBtdQblFldbenhBR8yTZDuyxrQ-LP&_nc_ohc=_CdCzBBl-zcQ7kNvwGrgROC&_nc_oc=AdrMTdxrFZIKyir7kEzGOelQJ7ZRjz8yh_Mc2QL0MfLbfnyh1QYoCdtX7HzyI92Ffe8&_nc_zt=24&_nc_ht=scontent.fhan17-1.fna&_nc_gid=JHdjHMMCq8azz6cbFcbrWA&_nc_ss=7b2a8&oh=00_Af-IDqHMqacf9pZmmv2_VWHHZVl7pCOGpMpzwFJHFzFt1g&oe=6A3DD287", // Full color portrait
    bio: "Student at Hanoi University of Science and Technology."
  }
];

export const initialPapers: ResearchPaper[] = [];

// Helper to generate dynamic, smart response based on text content / title
export function generateAnalysis(fileName: string, textContent?: string): ResearchPaper {
  const normTitle = (textContent || fileName).toLowerCase();
  
  let area = "General Research";
  let pi = "Dr. Michael Chen et al.";
  let journal = "Journal of Advanced Interdisciplinary Science";
  let doiSuffix = Math.floor(1000 + Math.random() * 9000);
  
  let topics = [
    {
      code: "Topic 01",
      name: "Core Theme Analysis",
      confidence: 95.4,
      description: `Detailed investigation of research objectives in: "${fileName}".`,
      tags: ["Analytical Model", "Core Concepts"]
    },
    {
      code: "Topic 02",
      name: "Methodological Framework",
      confidence: 88.2,
      description: "Evaluation of technical methods and statistical metrics used to optimize outcomes.",
      tags: ["Quantitative", "Heuristics"]
    },
    {
      code: "Topic 03",
      name: "Structural Insights",
      confidence: 81.0,
      description: "Detecting implicit relationships between raw data segments and proven theorems.",
      tags: ["Data Extraction", "Syntactic Parsing"]
    }
  ];

  let keywords = [
    { keyword: "Research", frequency: 120 },
    { keyword: "Methodology", frequency: 85 },
    { keyword: "Framework", frequency: 54 }
  ];

  let metrics = [
    {
      marker: "Semantic Pattern Matching",
      confidence: 0.9820,
      relevance: "Primary Methodology",
      status: "Validated" as const
    },
    {
      marker: "Statistical Convergence",
      confidence: 0.8912,
      relevance: "Supporting Metric",
      status: "Validated" as const
    },
    {
      marker: "Anomalous Sample Noise",
      confidence: 0.5120,
      relevance: "Irrelevant Mention",
      status: "Potential Noise" as const
    },
    {
      marker: "Temporal Context Filter",
      confidence: 0.3850,
      relevance: "Context Parameter",
      status: "Filtered" as const
    }
  ];

  // Fine-tuned topic generation based on keyword spot-checking
  if (normTitle.includes("ai") || normTitle.includes("neural") || normTitle.includes("intelligence") || normTitle.includes("trí tuệ nhân tạo") || normTitle.includes("học máy") || normTitle.includes("machine learning") || normTitle.includes("deep learning")) {
    area = "Artificial Intelligence";
    pi = "Prof. Dang Nguyen et al.";
    journal = "IEEE Transactions on Pattern Analysis and Machine Intelligence";
    topics = [
      {
        code: "Topic 01",
        name: "Artificial Intelligence & Deep Learning",
        confidence: 97.5,
        description: "Investigation of self-adaptive deep neural network architectures and backpropagation optimization algorithms.",
        tags: ["Deep Learning", "Neural Architectures", "Backpropagation"]
      },
      {
        code: "Topic 02",
        name: "Knowledge Representation & Transfer Learning",
        confidence: 89.4,
        description: "Extraction of sparse space embeddings and the contribution of few-shot learning models.",
        tags: ["Transfer Learning", "Embeddings", "Few-shot"]
      },
      {
        code: "Topic 03",
        name: "Regularization & Inference",
        confidence: 82.3,
        description: "Mitigating overfitting through random dropout techniques and batch normalization.",
        tags: ["Regularization", "Batch Norm", "Inference"]
      }
    ];
    keywords = [
      { keyword: "Neural Network", frequency: 192 },
      { keyword: "Embeddings", frequency: 114 },
      { keyword: "Loss Function", frequency: 68 }
    ];
    metrics = [
      { marker: "Gradient Descent Optimal", confidence: 0.9912, relevance: "Optimization Hub", status: "Validated" },
      { marker: "Dimensionality Reduction", confidence: 0.8520, relevance: "Pre-processing Support", status: "Validated" },
      { marker: "Hyperparameter Overfit", confidence: 0.6120, relevance: "Experimental Flaw", status: "Potential Noise" },
      { marker: "Pruning Thresholds", confidence: 0.4190, relevance: "Model Compression", status: "Filtered" }
    ];
  } else if (normTitle.includes("medical") || normTitle.includes("health") || normTitle.includes("y tế") || normTitle.includes("sinh học") || normTitle.includes("y dược") || normTitle.includes("cancer") || normTitle.includes("bio")) {
    area = "Biomedical Technology";
    pi = "Dr. Sarah Jenkins et al.";
    journal = "Lancet Digital Health & Biotechnology Journal";
    topics = [
      {
        code: "Topic 01",
        name: "Digital Medicine & Bioinformatics",
        confidence: 96.1,
        description: "Genetic genome sequence analysis using improved hidden Markov models and next-generation nucleotide sequencing.",
        tags: ["Genomics", "DNA Alignment", "Markov Models"]
      },
      {
        code: "Topic 02",
        name: "Molecular Screening & Therapeutics",
        confidence: 90.5,
        description: "Application of virtual molecular docking simulations to predict protein receptor binding affinities.",
        tags: ["Molecular Docking", "Ligands", "Proteomics"]
      },
      {
        code: "Topic 03",
        name: "Clinical Imaging & Diagnostics",
        confidence: 84.1,
        description: "Automated histopathology extraction from high-contrast digital slides.",
        tags: ["Histopathology", "Computer Vision"]
      }
    ];
    keywords = [
      { keyword: "Genome Sequence", frequency: 174 },
      { keyword: "Protein Receptor", frequency: 105 },
      { keyword: "Pathology", frequency: 51 }
    ];
    metrics = [
      { marker: "Sequence Correspondence", confidence: 0.9780, relevance: "Primary Marker", status: "Validated" },
      { marker: "Ligand Affinities", confidence: 0.8654, relevance: "Direct Biological Actor", status: "Validated" },
      { marker: "Imaging Speckle Noise", confidence: 0.5810, relevance: "Sensor Interferences", status: "Potential Noise" },
      { marker: "Cellular Demarcation", confidence: 0.3210, relevance: "Optional Annotations", status: "Filtered" }
    ];
  } else if (normTitle.includes("blockchain") || normTitle.includes("crypto") || normTitle.includes("mật mã") || normTitle.includes("an ninh") || normTitle.includes("security")) {
    area = "Cybersecurity & Cryptography";
    pi = "Prof. Alice Sterling et al.";
    journal = "IEEE Transactions on Information Forensics and Security";
    topics = [
      {
        code: "Topic 01",
        name: "Cryptography & Security",
        confidence: 98.1,
        description: "Design of secure zero-knowledge proof protocols for distributed transactions.",
        tags: ["Zero-Knowledge", "ZKP", "Cryptography"]
      },
      {
        code: "Topic 02",
        name: "Consensus Protocols",
        confidence: 88.7,
        description: "Optimizing Practical Byzantine Fault Tolerance (PBFT) in large-scale blockchain networks.",
        tags: ["Consensus", "PBFT", "Scalability"]
      },
      {
        code: "Topic 03",
        name: "Secure Smart Contracts",
        confidence: 79.5,
        description: "Automated formal verification to detect vulnerabilities in smart contracts.",
        tags: ["Formal Verification", "Solidity", "Reentrancy"]
      }
    ];
    keywords = [
      { keyword: "Consensus", frequency: 211 },
      { keyword: "Zero-Knowledge", frequency: 147 },
      { keyword: "Vulnerability", frequency: 63 }
    ];
    metrics = [
      { marker: "Cryptographic Proof Validity", confidence: 0.9992, relevance: "Absolute Security Proof", status: "Validated" },
      { marker: "Throughput TPS Scale", confidence: 0.8123, relevance: "Performance Efficiency", status: "Validated" },
      { marker: "Gas Optimization Flaw", confidence: 0.6901, relevance: "Static Compiler Alert", status: "Potential Noise" },
      { marker: "Miner Extractable Value", confidence: 0.4501, relevance: "Economic Side-Effects", status: "Filtered" }
    ];
  }

  // Generate a random clean paper ID
  const cleanId = fileName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

  return {
    id: cleanId || "custom-abstract",
    title: fileName.replace(/\.[a-zA-Z0-9]+$/, ""),
    analyzedAt: "Analysis complete",
    status: "PDF Analysis Complete",
    metadata: {
      principalInvestigator: pi,
      publicationYear: new Date().getFullYear(),
      academicJournal: journal,
      doi: `10.1016/j.${cleanId.substring(0, 8) || "art"}.${doiSuffix}`
    },
    topics,
    keywords,
    metrics,
    topologyImage: "/image1.jpeg"
  };
}
