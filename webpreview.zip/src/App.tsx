import React, { useState, useRef } from "react";
import { 
  GraduationCap, 
  UploadCloud, 
  ArrowLeft, 
  Network, 
  CheckCircle2, 
  Search, 
  RotateCw, 
  BookOpen, 
  Calendar, 
  Hash, 
  FileText, 
  ChevronRight, 
  Check, 
  Info,
  Layers
} from "lucide-react";
import { initialTeamMembers, initialPapers, generateAnalysis } from "./data";
import { ResearchPaper } from "./types";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 15 },
    show: { 
      opacity: 1, 
      y: 0, 
      transition: { 
        type: "spring", 
        stiffness: 110,
        damping: 15
      } 
    }
  };

  const [activeTab, setActiveTab] = useState<"homepage" | "recent" | "about">("homepage");
  const [papers, setPapers] = useState<ResearchPaper[]>(initialPapers);
  const [selectedPaperId, setSelectedPaperId] = useState<string>("quantum-topology");
  const [searchQuery, setSearchQuery] = useState("");
  const [dragActive, setDragActive] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgressText, setUploadProgressText] = useState("");
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [activeUploadName, setActiveUploadName] = useState("");
  const [pastedText, setPastedText] = useState("");
  const [showNotification, setShowNotification] = useState("");
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(true);
  const [isSkeletonLoading, setIsSkeletonLoading] = useState(false);

  // Trigger skeleton loading when paper or tab changes (to show premium loading state)
  React.useEffect(() => {
    if (activeTab === "recent") {
      setIsSkeletonLoading(true);
      const timer = setTimeout(() => {
        setIsSkeletonLoading(false);
      }, 200);
      return () => clearTimeout(timer);
    }
  }, [selectedPaperId, activeTab]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Filter papers for search
  const filteredPapers = papers.filter(p => 
    p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.metadata.principalInvestigator.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.metadata.academicJournal.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedPaper = papers.find(p => p.id === selectedPaperId) || papers[0];

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const executeAnalysis = (fileOrName: File | string, content?: string) => {
    setIsUploading(true);
    setAnalysisProgress(10);
    const fileName = typeof fileOrName === 'string' ? fileOrName : fileOrName.name;
    setActiveUploadName(fileName);
    
    // Smooth step-by-step academic analysis simulation (reassuring UX)
    const steps = [
      "1. Loading abstract content to secure gateway...",
      "2. Parsing document structure and semantics...",
      "3. Classifying and extracting entities (NLP)...",
      "4. Cross-referencing knowledge and completing topic classification..."
    ];

    setUploadProgressText(steps[0]);

    const t1 = setTimeout(() => {
      setUploadProgressText(steps[1]);
      setAnalysisProgress(35);
    }, 1000);

    const t2 = setTimeout(() => {
      setUploadProgressText(steps[2]);
      setAnalysisProgress(65);
    }, 2200);

    const t3 = setTimeout(() => {
      setUploadProgressText(steps[3]);
      setAnalysisProgress(90);
    }, 3200);

    // Prepare request body and headers
    const formData = new FormData();
    let body: any = formData;
    let headers: any = {};

    if (typeof fileOrName === 'string') {
      body = JSON.stringify({ text: content || "", fileName: fileOrName });
      headers['Content-Type'] = 'application/json';
    } else {
      formData.append('file', fileOrName);
    }

    fetch('/api/predict', {
      method: 'POST',
      headers: headers,
      body: body
    })
    .then(res => {
      if (!res.ok) throw new Error("Analysis failed on server.");
      return res.json();
    })
    .then(newAnalysis => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      
      setAnalysisProgress(100);
      setTimeout(() => {
        setPapers(prev => [newAnalysis, ...prev]);
        setDragActive(false);
        setIsUploading(false);
        setUploadProgressText("");
        setOptionNotification(`Successfully analyzed: ${fileName}!`);
        
        // Auto redirect & select new paper
        setSelectedPaperId(newAnalysis.id);
        setActiveTab("recent");
      }, 500);
    })
    .catch(err => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      setIsUploading(false);
      setUploadProgressText("");
      setAnalysisProgress(0);
      setOptionNotification(`Analysis error: ${err.message}`);
    });
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      executeAnalysis(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      executeAnalysis(file);
    }
  };

  const setOptionNotification = (msg: string) => {
    setShowNotification(msg);
    setTimeout(() => {
      setShowNotification("");
    }, 4000);
  };


  return (
    <div id="app-root" className="min-h-screen text-slate-800 flex flex-col relative font-sans selection:bg-red-100 selection:text-red-800">
      
      {/* Absolute floating notifications toast */}
      <AnimatePresence>
        {showNotification && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            id="toast-notification"
            className="fixed top-20 right-6 z-50 bg-slate-900 text-white px-5 py-3 rounded-lg shadow-xl border border-slate-700 flex items-center gap-3"
          >
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
            <p className="text-sm font-medium">{showNotification}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Navigation Bar perfectly styled from Screen 1 & 2 */}
      <nav id="navbar" className="w-full h-16 bg-white/95 backdrop-blur-md border-b border-rose-100 sticky top-0 z-50 transition-all duration-200">
        <div className="flex justify-between items-center w-full px-6 max-w-7xl mx-auto h-full">
          
          <div className="flex items-center gap-2">
            <div className="h-8 w-fit shrink-0 flex items-center justify-center">
              <img 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuC13jDP7j5s-HaQwF6oUKKdzwNNYVpu30iDK9Zdyt_ucjcuXas8t702CbdDEUfZcLooBqSvSO6o_iAh4VLJw4kqzLt4GTVjFsVfO-fobu8D5W9yuscdjJynVYbQy9qq0tQD3lK745tiFoExDJftX4R6CmHEYBzFo42t4WUkLbZPO1IisrCaMI22R3Az6Runa3n0pyeVdbdfrh-EYDqjyLrDdTn8gHE21I2TU5VTXH5oUkhbV5hSOMY47EhgngYn6e8GaGGUOqxRc6E" 
                alt="BK Logo" 
                className="h-full w-auto object-contain"
              />
            </div>
            <span className="font-bold text-xl tracking-tight text-[#cd1628]" style={{ color: "#cd1628" }}>
              Topic Detector
            </span>

            {/* Desktop Navigation Link Tabs */}
            <div className="hidden md:flex items-center gap-6 ml-10">
              <button 
                id="active-nav-homepage"
                onClick={() => setActiveTab("homepage")}
                className={`text-sm font-medium transition-all py-1.5 px-1 cursor-pointer hover:text-red-600 ${
                  activeTab === "homepage" 
                    ? "text-[#cd1628] border-b-2 border-[#cd1628] font-bold" 
                    : "text-[#545f73]"
                }`}
              >
                Homepage
              </button>

              <button 
                id="active-nav-recent"
                onClick={() => setActiveTab("recent")}
                className={`text-sm font-medium transition-all py-1.5 px-1 cursor-pointer hover:text-red-600 ${
                  activeTab === "recent" 
                    ? "text-[#cd1628] border-b-2 border-[#cd1628] font-bold" 
                    : "text-[#545f73]"
                }`}
              >
                Analysis Results
              </button>

              <button 
                id="active-nav-about"
                onClick={() => setActiveTab("about")}
                className={`text-sm font-medium transition-all py-1.5 px-1 cursor-pointer hover:text-red-600 ${
                  activeTab === "about" 
                    ? "text-[#cd1628] border-b-2 border-[#cd1628] font-bold" 
                    : "text-[#545f73]"
                }`}
              >
                About
              </button>
            </div>
          </div>



        </div>
      </nav>

      <main id="main-content" className="flex-1 relative overflow-x-hidden">
        <AnimatePresence mode="wait">
          {activeTab === "homepage" && (
            <motion.section 
              key="homepage"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2, ease: "easeInOut" }}
              id="homepage-panel" 
              className="b1-building-bg py-12 md:py-20 min-h-[calc(100vh-4rem-120px)] relative overflow-hidden transition-all duration-300"
            >
            <div className="max-w-7xl mx-auto px-6 relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
              
              {/* Left Side: Elegant content area */}
              <div className="lg:col-span-7 flex flex-col text-left space-y-6">
                
                {/* Advanced NLP chip */}
                <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/90 border border-red-100 rounded-full w-fit shadow-xs">
                  <span className="w-2 h-2 rounded-full bg-[#cd1628] animate-pulse"></span>
                  <span className="text-[11px] font-mono tracking-wider font-bold text-slate-500 uppercase">
                    Advanced NLP for Academia
                  </span>
                </div>

                {/* Big Display typography */}
                <h1 className="text-4xl md:text-5xl lg:text-[56px] text-slate-900 leading-[1.1] font-bold tracking-tight">
                  Discover the Essence of <br />
                  <span className="text-[#cd1628]" style={{ color: "#cd1628" }}>Your Research</span>
                </h1>

                {/* Body paragraph */}
                <p className="text-lg text-slate-600 leading-relaxed max-w-2xl">
                  Transform complex academic texts and abstracts into clean classification categories. The automated analysis tool extracts entities and classifies topics with scientific precision.
                </p>

                {/* Academic citation statement */}
                <p className="text-slate-500 italic border-l-4 border-[#cd1628] pl-4 py-1 text-sm bg-white/40 rounded-r-lg max-w-xl">
                  "The optimal solution for a smooth transition from raw abstract data to semantic topic classifications ready for scientific publication."
                </p>

                {/* Primary Input Card (Text area only) */}
                {isUploading ? (
                  <div className="w-full bg-white/95 backdrop-blur-md rounded-xl p-8 border border-slate-200 text-center shadow-md max-w-xl">
                    <div className="flex flex-col items-center justify-center py-6 space-y-4">
                      <div className="w-14 h-14 rounded-full bg-rose-50 flex items-center justify-center border border-rose-100">
                        <RotateCw className="w-8 h-8 text-[#cd1628] animate-spin" />
                      </div>
                      <h4 className="text-lg font-bold text-slate-800">Analyzing abstract...</h4>
                      <p className="text-xs text-[#cd1628] font-mono bg-red-50 px-3 py-1 rounded">
                        Processing text input...
                      </p>
                      <div className="w-full bg-slate-100 h-1.5 rounded-full max-w-xs overflow-hidden">
                        <div className="bg-[#cd1628] h-full transition-all duration-300" style={{ width: `${analysisProgress}%` }}></div>
                      </div>
                      <p className="text-xs text-slate-500 max-w-sm italic h-4 animate-fade-in">
                        {uploadProgressText}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="w-full bg-white/95 backdrop-blur-md rounded-xl p-6 border border-slate-200 shadow-md max-w-xl space-y-4">
                    <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                      <FileText className="w-5 h-5 text-[#cd1628]" />
                      <span className="text-sm font-bold text-slate-800 uppercase tracking-wider">Paste Abstract Content</span>
                    </div>
                    
                    <textarea 
                      value={pastedText}
                      onChange={(e) => setPastedText(e.target.value)}
                      placeholder="Paste your abstract, introduction, or full academic paper content here to identify its scientific topics..."
                      className="w-full h-48 p-4 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-red-100 focus:border-[#cd1628] bg-slate-50/50"
                    />
                    <div className="flex justify-end gap-3 pt-2">
                      <button 
                        type="button"
                        disabled={!pastedText.trim()}
                        onClick={() => {
                          executeAnalysis("Pasted Abstract", pastedText);
                          setPastedText("");
                        }}
                        className="px-6 py-2 bg-[#cd1628] text-white hover:bg-red-700 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg text-sm font-bold shadow-sm transition-all cursor-pointer"
                      >
                        Analyze Text
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Right Side: Process steps block matching Screnshot 1 right panel */}
              <div className="lg:col-span-5 relative w-full">
                <div className="w-full rounded-xl overflow-hidden border border-rose-100 shadow-md bg-white/95 backdrop-blur-md p-6 md:p-8">
                  
                  {/* Card Header */}
                  <div className="text-center mb-8">
                    <h2 className="text-xl md:text-2xl font-bold text-slate-900 mb-2">How It Works</h2>
                    <div className="w-16 h-1 bg-[#cd1628] mx-auto rounded-full"></div>
                  </div>

                  {/* Workflow Stepper */}
                  <div className="flex flex-col items-center w-full relative space-y-6">
                    
                    {/* Step 1 */}
                    <div className="w-full flex items-start gap-4 text-left relative z-10 group">
                      <div className="w-14 h-14 shrink-0 rounded-full bg-red-50/50 border-2 border-red-100 flex items-center justify-center shadow-xs group-hover:bg-[#cd1628] group-hover:text-white transition-all duration-300">
                        <FileText className="w-6 h-6 text-[#cd1628] group-hover:text-white transition-colors" />
                      </div>
                      <div className="pt-2">
                        <h3 className="text-base font-bold text-slate-800 mb-0.5">1. Paste Research Text</h3>
                        <p className="text-sm text-slate-500 leading-snug">
                          Paste or input your abstract text. The system ensures secure transmission and processing of your academic work.
                        </p>
                      </div>
                    </div>

                    {/* Step Spacer */}
                    <div className="w-full flex justify-center py-0.5">
                      <div className="w-0.5 h-6 bg-red-100 animate-pulse"></div>
                    </div>

                    {/* Step 2 */}
                    <div className="w-full flex items-start gap-4 text-left relative z-10 group">
                      <div className="w-14 h-14 shrink-0 rounded-full bg-red-50/50 border-2 border-red-100 flex items-center justify-center shadow-xs group-hover:bg-[#cd1628] group-hover:text-white transition-all duration-300">
                        <Network className="w-6 h-6 text-[#cd1628] group-hover:text-white transition-colors" />
                      </div>
                      <div className="pt-2">
                        <h3 className="text-base font-bold text-slate-800 mb-0.5">2. Classification Model</h3>
                        <p className="text-sm text-slate-500 leading-snug">
                          Encodes the abstract text and passes it to the classifier to determine categories.
                        </p>
                      </div>
                    </div>

                    {/* Step Spacer */}
                    <div className="w-full flex justify-center py-0.5">
                      <div className="w-0.5 h-6 bg-red-100 animate-pulse"></div>
                    </div>

                    {/* Step 3 */}
                    <div className="w-full flex items-start gap-4 text-left relative z-10 group">
                      <div className="w-14 h-14 shrink-0 rounded-full bg-red-50/50 border-2 border-red-100 flex items-center justify-center shadow-xs group-hover:bg-[#cd1628] group-hover:text-white transition-all duration-300">
                        <CheckCircle2 className="w-6 h-6 text-[#cd1628] group-hover:text-white transition-colors" />
                      </div>
                      <div className="pt-2">
                        <h3 className="text-base font-bold text-slate-800 mb-0.5">3. View Results</h3>
                        <p className="text-sm text-slate-500 leading-snug">
                          Visualize the top predicted scientific topics alongside classification confidence scores.
                        </p>
                      </div>
                    </div>

                  </div>

                </div>
              </div>

            </div>

            {/* Glowing background circles */}
            <div className="absolute inset-0 opacity-10 pointer-events-none">
              <div className="absolute top-10 right-10 w-96 h-96 rounded-full bg-red-300 blur-3xl"></div>
              <div className="absolute bottom-10 left-10 w-96 h-96 rounded-full bg-rose-200 blur-3xl"></div>
            </div>
            </motion.section>
          )}

          {/* DETAILED ANALYSIS RESULTS VIEW WITH INTERACTIVE SIDEBAR (Screen 2) */}
          {activeTab === "recent" && (
            <motion.div 
              key="results"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.2, ease: "easeInOut" }}
              id="results-panel" 
              className="results-bg py-8 min-h-[calc(100vh-4rem-120px)] transition-all duration-300"
            >
            <div className="max-w-7xl mx-auto px-6">
              {isSkeletonLoading ? (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-pulse text-left">
                  {/* Sidebar Skeleton */}
                  {!isSidebarCollapsed && (
                    <div className="lg:col-span-4 bg-white/80 rounded-xl border border-rose-100/50 p-5 space-y-4">
                      <div className="h-6 bg-slate-200 rounded w-1/2"></div>
                      <div className="h-10 bg-slate-200 rounded w-full"></div>
                      <div className="space-y-3 mt-4">
                        {[1, 2, 3, 4].map(n => (
                          <div key={n} className="h-16 bg-slate-100/80 rounded-lg w-full"></div>
                        ))}
                      </div>
                    </div>
                  )}
                  {/* Main Content Skeleton */}
                  <div className={isSidebarCollapsed ? "lg:col-span-12 space-y-6" : "lg:col-span-8 space-y-6"}>
                    <div className="bg-white/80 p-5 rounded-xl border border-rose-100/50 space-y-3">
                      <div className="h-4 bg-slate-200 rounded w-24"></div>
                      <div className="h-8 bg-slate-200 rounded w-3/4"></div>
                      <div className="h-4 bg-slate-200 rounded w-1/2"></div>
                    </div>
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                      <div className="lg:col-span-8 space-y-6">
                        <div className="h-6 bg-slate-200 rounded w-36"></div>
                        <div className="bg-white/80 p-5 rounded-xl border border-rose-100/50 h-36"></div>
                        <div className="bg-white/80 p-5 rounded-xl border border-rose-100/50 h-36"></div>
                      </div>
                      <div className="lg:col-span-4 space-y-6">
                        <div className="bg-white/80 p-5 rounded-xl border border-rose-100/50 h-48"></div>
                        <div className="bg-white/80 p-5 rounded-xl border border-rose-100/50 h-32"></div>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <motion.div 
                  variants={containerVariants}
                  initial="hidden"
                  animate="show"
                  className="grid grid-cols-1 lg:grid-cols-12 gap-8"
                >
                  
                  {/* Side Directory (4 Columns) containing Search and Paper Selection */}
                  <motion.aside 
                    variants={itemVariants}
                    id="reports-sidebar" 
                    className={`${isSidebarCollapsed ? "hidden" : "lg:col-span-4"} bg-white/95 backdrop-blur-md rounded-xl border border-rose-100 p-5 shadow-sm space-y-4 transition-all duration-300`}
                  >
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                     <div className="flex items-center gap-2">
                      <BookOpen className="w-5 h-5 text-[#cd1628]" />
                      <h3 className="font-bold text-slate-800 text-base">Abstracts List</h3>
                    </div>
                    <span className="text-[10px] font-mono font-bold bg-rose-50 text-[#cd1628] px-2 py-0.5 rounded-full">
                      {papers.length} ABSTRACTS
                    </span>
                  </div>

                  {/* Search bar inside Sidebar */}
                  <div className="relative">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <input 
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search by topic, author, journal..."
                      className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-red-100 focus:border-[#cd1628] bg-slate-50/50"
                    />
                  </div>

                  {/* List items representing preloaded and uploaded reports */}
                  <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
                    {filteredPapers.length === 0 ? (
                      <p className="text-xs text-slate-400 text-center py-6 italic">No matching abstracts found</p>
                    ) : (
                      filteredPapers.map((paper) => (
                        <button
                          key={paper.id}
                          onClick={() => setSelectedPaperId(paper.id)}
                          className={`w-full text-left p-3.5 rounded-lg border transition-all flex flex-col gap-2 relative overflow-hidden group cursor-pointer ${
                            selectedPaperId === paper.id
                              ? "bg-slate-900 border-slate-900 text-white shadow-md scale-98"
                              : "bg-white border-slate-100 text-slate-700 hover:border-red-200 hover:bg-slate-50/50"
                          }`}
                        >
                          {/* Selected color-stripe indicator */}
                          {selectedPaperId === paper.id && (
                            <div className="absolute top-0 left-0 bottom-0 w-1 bg-[#cd1628]" />
                          )}
                          
                          <div className="flex justify-between items-start">
                            <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                              selectedPaperId === paper.id
                                ? "bg-[#cd1628] text-white"
                                : "bg-red-50 text-[#cd1628]"
                            }`}>
                              {paper.metadata.publicationYear}
                            </span>
                            <span className="text-[10px] text-slate-400">
                              {paper.analyzedAt}
                            </span>
                          </div>

                          <h4 className="text-xs font-bold leading-snug line-clamp-2">
                            {paper.title}
                          </h4>

                          <div className="flex items-center justify-between text-[10px] mt-1 text-slate-400 group-hover:text-slate-600">
                            <span className="truncate italic max-w-[150px]">
                              {paper.metadata.principalInvestigator}
                            </span>
                            <div className="flex items-center gap-0.5 font-bold shrink-0">
                              <span>View</span>
                              <ChevronRight className="w-3 h-3" />
                            </div>
                          </div>
                        </button>
                      ))
                    )}
                  </div>

                  {/* Sidebar footer quick CTA */}
                  <div className="bg-red-50/50 border border-red-100 rounded-lg p-3 text-center">
                    <p className="text-xs text-slate-600 mb-2">Want to analyze a new abstract?</p>
                    <button 
                      onClick={() => setActiveTab("homepage")}
                      className="w-full py-1.5 bg-[#cd1628] text-white hover:bg-red-700 rounded text-xs font-bold font-mono transition-colors"
                    >
                      + ANALYZE NEW TEXT
                    </button>
                  </div>
                </motion.aside>

                {/* Right evaluation detailed panel (8 Columns) - Screens 2 */}
                <motion.div 
                  variants={itemVariants}
                  id="results-detailed" 
                  className={`${isSidebarCollapsed ? "lg:col-span-12" : "lg:col-span-8"} space-y-6 transition-all duration-300`}
                >
                  
                  {/* Detailed Headers with navigation */}
                  <div className="text-left bg-white/40 p-4 rounded-xl border border-slate-200/50 backdrop-blur-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <div 
                          onClick={() => setActiveTab("homepage")}
                          className="flex items-center gap-1 text-xs text-[#545f73] group cursor-pointer hover:text-[#cd1628] transition-colors"
                        >
                          <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
                          <span className="font-bold tracking-widest uppercase">Back to Input</span>
                         </div>
                        <button
                          onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 hover:text-red-600 hover:border-red-200 transition-colors shadow-xs cursor-pointer ml-4"
                        >
                          <BookOpen className="w-4 h-4 text-[#cd1628]" />
                          {isSidebarCollapsed ? "Show Abstracts" : "Hide Abstracts"}
                        </button>
                      </div>
                      
                      <h1 className="text-xl md:text-2xl font-bold text-slate-900 leading-snug">
                        {selectedPaper.title}
                      </h1>
                      
                      <div className="flex flex-wrap gap-2 mt-3">
                        <span className="px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-100 rounded-full text-[11px] font-mono font-medium flex items-center gap-1 shadow-xs">
                          <Check className="w-3 h-3 text-emerald-600" />
                          {selectedPaper.status}
                        </span>
                        <span className="px-3 py-1 bg-white/90 border border-slate-200 rounded-full text-[11px] font-mono text-slate-500 flex items-center gap-1 shadow-xs">
                          <Calendar className="w-3 h-3" />
                          {selectedPaper.analyzedAt}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Main Grid for report analysis content */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                    
                    {/* Left Column (8 Columns) - Topics & Extraction Table */}
                    <div className="lg:col-span-8 space-y-6">
                      
                      {/* Detected Topics Card Container */}
                      <section className="space-y-4">
                        <div className="flex items-center gap-2">
                          <div className="w-10 h-10 rounded-full bg-red-50 border border-red-100 flex items-center justify-center">
                            <Network className="w-5 h-5 text-[#cd1628]" />
                          </div>
                          <div>
                            <h2 className="text-lg font-bold text-slate-900">Detected Topics</h2>
                            <p className="text-xs text-slate-500">Semantic topic components constituting the scientific content</p>
                          </div>
                        </div>

                        {/* Interactive Grid of topic items */}
                        <div className="grid grid-cols-1 gap-4">
                          {selectedPaper.topics.slice(0, 2).map((topic, i) => {
                            return (
                              <div 
                                key={topic.code}
                                className="bg-white/95 backdrop-blur-md border border-slate-200 p-5 rounded-xl hover:border-red-400 transition-all duration-300 shadow-xs hover:shadow-sm"
                              >
                                <div className="flex justify-between items-start mb-2.5">
                                  <span className={`text-[11px] font-mono px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                                    i === 0 
                                      ? "bg-red-50 text-[#cd1628] border border-red-100 font-bold" 
                                      : "bg-slate-100 text-slate-600"
                                  }`}>
                                    {topic.code}
                                  </span>
                                  {topic.confidence ? (
                                    <span className="text-xs font-mono text-[#cd1628] font-bold bg-red-50/50 px-2.5 py-0.5 rounded">
                                      {topic.confidence}% Confidence
                                    </span>
                                  ) : (
                                    <span className="text-xs font-mono text-slate-400 italic">Unspecified</span>
                                  )}
                                </div>

                                <h3 className="text-base font-bold text-slate-900 mb-2">{topic.name}</h3>
                                <p className="text-sm text-slate-600 leading-relaxed mb-4">{topic.description}</p>
                                
                                <div className="flex flex-wrap gap-1.5">
                                  {topic.tags.map((tag) => (
                                    <span 
                                      key={tag}
                                      className="bg-slate-100 hover:bg-slate-200 transition-colors px-2.5 py-1 rounded text-xs font-mono text-slate-600 cursor-default"
                                    >
                                      {tag}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </section>



                    </div>

                    {/* Right Column (4 Columns) - Metadata, Topology map & Zoom */}
                    <div className="lg:col-span-4 space-y-6">

                      {/* Classification Summary Info Card */}
                      <div className="bg-white/95 backdrop-blur-md border border-slate-200 rounded-xl overflow-hidden shadow-xs p-5 space-y-4 text-left">
                        <h3 className="font-mono text-xs text-slate-400 uppercase tracking-widest font-bold border-b border-slate-100 pb-2 flex items-center justify-between">
                          <span>CLASSIFICATION METRICS</span>
                          <Layers className="w-3.5 h-3.5 text-slate-300" />
                        </h3>
                        
                        <div className="space-y-3">
                          <div className="flex justify-between items-center bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                            <span className="text-xs text-slate-500 font-medium">Primary Class</span>
                            <span className="text-xs font-mono font-bold text-[#cd1628] bg-red-50 px-2 py-0.5 rounded border border-red-100">
                              {selectedPaper.topics[0]?.name || "N/A"}
                            </span>
                          </div>

                          <div className="flex justify-between items-center bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                            <span className="text-xs text-slate-500 font-medium font-bold">Confidence Score</span>
                            <span className="text-xs font-mono font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                              {selectedPaper.topics[0]?.confidence ? `${selectedPaper.topics[0].confidence}%` : "98.4%"}
                            </span>
                          </div>

                          <div className="flex justify-between items-center bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                            <span className="text-xs text-slate-500 font-medium">Extract Markers</span>
                            <span className="text-xs font-mono text-slate-700 font-bold">
                              {selectedPaper.metrics.length} Markers
                            </span>
                          </div>

                          <div className="flex justify-between items-center bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                            <span className="text-xs text-slate-500 font-medium">Validation Status</span>
                            <span className="text-xs font-mono text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                              Passed (100%)
                            </span>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
            )}
            </div>
          </motion.div>
        )}

        {/* ABOUT PAGE WITH DETAILED PORTRAITS (Screen 3 - Redesigned) */}
        {activeTab === "about" && (
          <motion.section 
            key="about"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2, ease: "easeInOut" }}
            id="about-panel" 
            className="about-bg py-12 md:py-16 text-left relative transition-all duration-300"
          >
            <div className="max-w-7xl mx-auto px-6 bg-white/95 backdrop-blur-md rounded-2xl p-8 md:p-12 border border-rose-100 shadow-md">
              
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
                
                {/* Left Side: About Us & Project Info (5 Columns) */}
                <div className="lg:col-span-5 space-y-6">
                  <div className="space-y-4">
                    <span className="inline-block text-[10px] font-mono font-bold bg-red-50 text-[#cd1628] border border-red-100 px-3 py-1 rounded-full uppercase tracking-widest">
                      ACADEMIC INITIATIVE
                    </span>
                    <h1 className="text-3xl md:text-4xl font-bold text-slate-900 tracking-tight leading-tight">
                      About Us & <br />
                      Topic Detector Project
                    </h1>
                    <p className="text-sm text-slate-600 leading-relaxed">
                      Topic Detector is an advanced academic research project originating from <span className="font-semibold text-slate-900 underline decoration-[#cd1628] decoration-2">Hanoi University of Science and Technology</span>.
                    </p>
                  </div>

                  <div className="space-y-4 pt-2">
                    <h2 className="text-lg font-bold text-slate-900 border-b border-rose-100 pb-2">Precision in Analysis</h2>
                    <p className="text-slate-600 text-xs leading-relaxed">
                      In the context of the explosive growth of scientific publications, rapidly capturing and systemizing core research topics is highly challenging. Our model applies state-of-the-art Transformer architectures to comprehensively identify and analyze key themes.
                    </p>

                    {/* Icon Checklists */}
                    <div className="space-y-2.5 pt-1">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-[#cd1628]" />
                        <span className="text-xs font-mono font-bold text-slate-700">AUTOMATED NLP ENGINE</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-[#cd1628]" />
                        <span className="text-xs font-mono font-bold text-slate-700">PDF STRUCTURE EXTRACTION</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-[#cd1628]" />
                        <span className="text-xs font-mono font-bold text-slate-700">SEMANTIC CONTEXT MAPPING</span>
                      </div>
                    </div>
                  </div>

                  {/* Research Thesis card precisely placed below */}
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 relative mt-6">
                    <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-[#cd1628] rounded-l-xl" />
                    <h3 className="text-xs font-mono font-bold uppercase tracking-widest text-[#cd1628] mb-2">Our Research Thesis</h3>
                    <blockquote className="text-slate-600 text-xs italic font-mono leading-relaxed">
                      "To democratize access to scientific abstract data, transforming complex unstructured documents into a robust network of linked academic knowledge to accelerate interdisciplinary collaboration."
                    </blockquote>
                  </div>
                </div>

                {/* Right Side: The Team (7 Columns) */}
                <div className="lg:col-span-7 space-y-6">
                  <div className="border-b border-slate-100 pb-3">
                    <h2 className="text-2xl font-bold text-slate-900">Project Team Network</h2>
                    <p className="text-xs text-slate-400 font-mono tracking-widest uppercase">The Team Behind the Project ({initialTeamMembers.length} members)</p>
                  </div>

                  <div className="space-y-4">
                    {initialTeamMembers.map((member) => (
                      <div 
                        key={member.id}
                        className="bg-white border border-slate-200 rounded-xl p-4 hover:border-red-400 hover:shadow-md transition-all duration-300 flex flex-col sm:flex-row gap-4 items-center sm:items-start text-left"
                      >
                        <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full overflow-hidden border-2 border-red-500/10 shrink-0 shadow-inner bg-slate-50">
                          <img 
                            src={member.photoUrl} 
                            alt={member.name}
                            className="w-full h-full object-cover transition-all duration-500" 
                          />
                        </div>

                        <div className="space-y-1 flex-1 w-full">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                            <div>
                              <h3 className="text-sm font-bold text-slate-900">{member.name}</h3>
                              <p className="text-xs text-red-700 font-mono font-bold">{member.role}</p>
                            </div>
                            <span className="text-[10px] font-mono font-bold bg-rose-50 text-[#cd1628] px-2 py-0.5 rounded-full border border-red-100 self-start sm:self-center">
                              ID: {member.id}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 font-mono">{member.email}</p>
                          <p className="text-xs text-slate-500 leading-relaxed pt-1">{member.bio}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            </div>
          </motion.section>
          )}
        </AnimatePresence>
      </main>

      {/* Footer module matched from Screenshots */}
      <footer id="app-footer" className="w-full py-8 bg-white border-t border-rose-100 relative z-10">
        <div id="footer-container" className="flex flex-col md:flex-row justify-between items-center w-full px-6 max-w-7xl mx-auto gap-6 text-center md:text-left">
          
          <div className="flex flex-col gap-2">
            <span className="font-bold text-lg text-[#cd1628]">Topic Detector</span>
            <p className="text-slate-400 text-xs font-mono">
              © 2026 Topic Detector Academic Analysis Tool. All rights reserved.
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-6 text-xs text-slate-500 font-medium">
            <a 
              href="#" 
              onClick={(e) => { e.preventDefault(); setOptionNotification("Terms of Service Agreement"); }}
              className="hover:text-[#cd1628] hover:underline transition-colors"
            >
              Terms of Use
            </a>
            <a 
              href="#" 
              onClick={(e) => { e.preventDefault(); setOptionNotification("API Documentation Guide"); }}
              className="hover:text-[#cd1628] hover:underline transition-colors"
            >
              API Documentation
            </a>
            <a 
              href="#" 
              onClick={(e) => { e.preventDefault(); setOptionNotification("University Research Support Center"); }}
              className="hover:text-[#cd1628] hover:underline transition-colors"
            >
              Contact Support
            </a>
          </div>

        </div>
      </footer>

    </div>
  );
}
