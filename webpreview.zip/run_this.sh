#!/bin/bash
# Exit on error
set -e

echo "=========================================="
echo " Starting Topic Detector System"
echo "=========================================="

# Check if venv exists
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
    echo "Installing backend dependencies..."
    ./venv/bin/pip install scikit-learn joblib sentence-transformers flask flask-cors pypdf docx2txt
fi

# Start Python backend in the background
echo "Starting Python ML Server on http://127.0.0.1:5000..."
./venv/bin/python3 server.py &
BACKEND_PID=$!

# Ensure backend is killed when script exits
cleanup() {
    echo "Stopping Python ML Server (PID $BACKEND_PID)..."
    kill $BACKEND_PID 2>/dev/null || true
}
trap cleanup EXIT

# Wait for backend to initialize and open port 5000
echo "Waiting for Python ML Server to load models and start listening..."
for i in {1..30}; do
    if bash -c 'cat < /dev/null > /dev/tcp/127.0.0.1/5000' 2>/dev/null; then
        echo "Backend is ready on port 5000!"
        break
    fi
    sleep 1
done

# Start Vite frontend
echo "Starting Vite Dev Server..."
npm run dev
