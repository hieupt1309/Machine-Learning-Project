class LinearSVMScratch:
    pass
